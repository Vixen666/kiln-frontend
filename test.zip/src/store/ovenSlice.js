// src/store/ovenSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import config from '../config';

export const fetchOvens = createAsyncThunk(
  'oven/fetchOvens',
  async (_, { rejectWithValue }) => {
    const url = `${config.apiUrl}/api/OvenService/Get_All`;
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      let data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue('Network problem while fetching ovens.');
    }
  }
);

export const saveOven = createAsyncThunk(
  'oven/saveOven',
  async (oven, { rejectWithValue }) => {
    console.log('saveOven thunk dispatched');
    const url = `${config.apiUrl}/api/OvenService/Save`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(oven),
      });
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const result = await response.json();
      return result;
    } catch (error) {
      return rejectWithValue('Network problem while saving oven.');
    }
  }
);

const ovenSlice = createSlice({
  name: 'oven',
  initialState: {
    ovens: [],
    selectedOven: null,
    status: 'idle',
    error: null,
  },
  reducers: {
    selectOven: (state, action) => {
      state.selectedOven = action.payload;
    },
    newOven: (state) => {
      state.selectedOven = {};
    },
    updateOvenField: (state, action) => {
      const { field, value } = action.payload;
      if (state.selectedOven) {
        state.selectedOven[field] = value;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchOvens.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchOvens.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.ovens = action.payload;
      })
      .addCase(fetchOvens.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(saveOven.pending, (state) => {
        console.log('saveOven pending');
      })
      .addCase(saveOven.fulfilled, (state, action) => {
        
        // Optionally, handle the state update after save
      })
      .addCase(saveOven.rejected, (state, action) => {
        console.log('saveOven rejected');
        state.error = action.payload;
      });
  },
});

export const { selectOven, newOven, updateOvenField } = ovenSlice.actions;
export default ovenSlice.reducer;
