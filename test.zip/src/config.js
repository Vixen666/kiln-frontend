const config = {
  apiUrl: "http://192.168.0.21:5000",
  //apiUrl: "http://83.254.139.178:5000",
  // Add other global configuration settings here
};

export default config;
