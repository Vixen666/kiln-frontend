import React from 'react';
import {  Grid } from '@mui/material';

function HomePage() {
  return (
    <Grid container spacing={2} style={{marginTop: '20px'}}>
      

    </Grid>
  );
}

export default HomePage;
